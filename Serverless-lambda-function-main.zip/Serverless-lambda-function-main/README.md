# Serverless-lambda-function
serverless lambda in aws
